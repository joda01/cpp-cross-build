#include <iostream>

int main()
{
    std::cout << "works" << std::endl;
    return 0;
}
