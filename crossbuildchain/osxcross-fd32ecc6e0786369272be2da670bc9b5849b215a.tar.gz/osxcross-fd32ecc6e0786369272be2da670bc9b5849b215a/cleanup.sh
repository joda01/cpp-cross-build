#!/usr/bin/env bash

git clean -fdx || rm -rf *~ build target *.tar.xz
